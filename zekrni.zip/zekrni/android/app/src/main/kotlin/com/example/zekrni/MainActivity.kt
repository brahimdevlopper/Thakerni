package com.example.zekrni

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
